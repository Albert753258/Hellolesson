#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm yespowertide --pool eu.poolmine.xyz:6243 --wallet TSmfmLMBnufPRQVPgPXEB2qpqrFMjrVRja --password c=TIDE
